#!/bin/bash

echo "Starting Nginx..."
sudo service nginx start
