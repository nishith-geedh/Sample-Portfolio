#!/bin/bash
echo "Stopping Nginx..."
sudo service nginx stop